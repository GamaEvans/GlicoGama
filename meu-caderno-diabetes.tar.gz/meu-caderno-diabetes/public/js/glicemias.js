import { api } from './api.js';
const $ = id => document.getElementById(id);
const MOMENTS = { jejum:'Em jejum', antes_almoco:'Antes do almoço', depois_almoco:'Depois do almoço', antes_janta:'Antes da janta', depois_janta:'Depois da janta', antes_outras:'Antes de outras refeições', depois_outras:'Depois de outras refeições', antes_dormir:'Antes de dormir', madrugada:'Madrugada', avulsa:'Medição avulsa' };
let user, editId = null, chart;
$('moment').replaceChildren(...Object.entries(MOMENTS).map(([k, v]) => new Option(v, k)));
const localInput = d => new Date(d.getTime() - d.getTimezoneOffset() * 60000).toISOString().slice(0, 16);
const fmt = d => new Date(d).toLocaleString('pt-BR', { dateStyle: 'short', timeStyle: 'short' });
// Exibe sempre na unidade preferida; o valor original continua guardado no banco.
const show = mg => user.glucose_unit === 'mmol/L' ? (mg / 18.016).toFixed(1) : Math.round(mg);
const cell = (tr, label, text) => { const td = tr.insertCell(); td.dataset.l = label; td.textContent = text; return td; };

async function load() {
  const from = new Date(Date.now() - $('period').value * 864e5).toISOString();
  const { readings, stats } = await api(`/glucose?from=${encodeURIComponent(from)}&order=desc`);
  const u = user.glucose_unit;
  $('stats').replaceChildren(...(stats.count ? [['Medições', stats.count], ['Média', show(stats.avg_mgdl) + ' ' + u], ['Mínimo', show(stats.min_mgdl) + ' ' + u], ['Máximo', show(stats.max_mgdl) + ' ' + u]] : []).map(([l, v]) => { const d = document.createElement('div'); d.className = 'stat'; d.append(l, Object.assign(document.createElement('b'), { textContent: v })); return d; }));
  $('empty').textContent = $('chart-empty').textContent = readings.length ? '' : 'Ainda não há registros neste período. Que tal anotar a primeira? ⭐';
  const tb = $('rows'); tb.replaceChildren();
  for (const r of readings) {
    const tr = tb.insertRow(); cell(tr, 'Data', fmt(r.measured_at)); cell(tr, 'Momento', MOMENTS[r.moment]);
    cell(tr, 'Valor', `${show(r.value_mgdl)} ${u}` + (r.unit_original !== u ? ` (anotado: ${r.value_original} ${r.unit_original})` : '')); cell(tr, 'Obs.', r.notes || '—');
    const td = tr.insertCell(); for (const [t, fn] of [['Editar', () => edit(r)], ['Excluir', () => del(r)]]) { const b = document.createElement('button'); b.type = 'button'; b.textContent = t; b.onclick = fn; td.append(b, ' '); }
  }
  const pts = [...readings].reverse();
  chart?.destroy();
  if (pts.length) chart = new Chart($('chart'), { type: 'line', data: { labels: pts.map(r => fmt(r.measured_at)), datasets: [{ label: `Glicemia (${u})`, data: pts.map(r => +show(r.value_mgdl)), borderColor: '#4277B8', backgroundColor: '#FFE58A', pointRadius: 5, tension: .2 }] }, options: { plugins: { tooltip: { callbacks: { afterLabel: c => MOMENTS[pts[c.dataIndex].moment] } } } } });
}
function edit(r) { editId = r.id; $('value').value = r.value_original; $('unit').value = r.unit_original; $('when').value = localInput(new Date(r.measured_at)); $('moment').value = r.moment; $('notes').value = r.notes || ''; $('form-title').textContent = 'Editar registro ✏️'; $('cancel').hidden = false; $('value').focus(); }
function reset() { editId = null; $('gform').reset(); $('unit').value = user.glucose_unit; $('when').value = localInput(new Date()); $('form-title').textContent = 'Registrar glicemia ✏️'; $('cancel').hidden = true; }
async function del(r) { if (!confirm('Excluir este registro? Isso não pode ser desfeito.')) return; await api('/glucose/' + r.id, { method: 'DELETE' }); load(); }
$('cancel').onclick = reset; $('period').onchange = load;
$('gform').addEventListener('submit', async e => {
  e.preventDefault(); const btn = e.submitter; btn.disabled = true; const m = $('gmsg'); m.className = 'msg';
  try {
    await api(editId ? '/glucose/' + editId : '/glucose', { method: editId ? 'PATCH' : 'POST', body: { value: +$('value').value, unit: $('unit').value, measured_at: new Date($('when').value).toISOString(), moment: $('moment').value, notes: $('notes').value || null } });
    m.className = 'msg ok'; m.textContent = 'Anotado no caderno! ⭐'; reset(); await load();
  } catch (err) { m.className = 'msg err'; m.textContent = err.message; } finally { btn.disabled = false; }
});
$('logout').onclick = async () => { await api('/auth/logout', { method: 'POST' }); location.href = '/login.html'; };
try { user = await api('/auth/me'); $('hello').textContent = `Olá, ${user.name}!`; reset(); await load(); } catch { location.href = '/login.html'; }

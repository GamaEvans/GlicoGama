import { api } from './api.js';
const form = document.getElementById('auth-form'), msg = document.getElementById('msg');
const mode = form.dataset.mode;
form.addEventListener('submit', async e => {
  e.preventDefault(); const btn = form.querySelector('button'); btn.disabled = true; msg.className = 'msg'; msg.textContent = 'Enviando…';
  const f = Object.fromEntries(new FormData(form));
  try { await api('/auth/' + mode, { method: 'POST', body: f }); location.href = '/dashboard.html'; }
  catch (err) { msg.className = 'msg err'; msg.textContent = err.message; btn.disabled = false; }
});

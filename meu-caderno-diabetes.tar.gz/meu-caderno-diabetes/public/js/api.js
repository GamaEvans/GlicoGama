// Cliente da API. Todas as chamadas passam por aqui (cabeçalho anti-CSRF + tratamento de erros).
export async function api(path, { method = 'GET', body } = {}) {
  const res = await fetch('/api' + path, { method, credentials: 'same-origin',
    headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'caderno' }, body: body ? JSON.stringify(body) : undefined });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) { const e = new Error(data.error || 'Algo deu errado.'); e.status = res.status; throw e; }
  return data;
}

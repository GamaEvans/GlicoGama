import { Router } from 'express';
import bcrypt from 'bcryptjs';
import rateLimit from 'express-rate-limit';
import { z } from 'zod';
import { pool } from '../db.js';
const r = Router();
const limiter = rateLimit({ windowMs: 15*60*1000, max: 10, message: { error: 'Muitas tentativas. Aguarde alguns minutos.' } });
const reg = z.object({ name: z.string().trim().min(1).max(80), email: z.string().trim().toLowerCase().email().max(200), password: z.string().min(10).max(128) });
const log = z.object({ email: z.string().trim().toLowerCase().email(), password: z.string().min(1).max(128) });
const start = (req, u) => new Promise((ok, no) => req.session.regenerate(e => { if (e) return no(e); req.session.userId = u.id; ok(); }));

r.post('/register', limiter, async (req, res) => {
  const p = reg.safeParse(req.body);
  if (!p.success) return res.status(400).json({ error: 'Verifique nome, e-mail e senha (mínimo 10 caracteres).' });
  const hash = await bcrypt.hash(p.data.password, 12);
  try {
    const { rows } = await pool.query('INSERT INTO users(name,email,password_hash) VALUES($1,$2,$3) RETURNING id,name,glucose_unit', [p.data.name, p.data.email, hash]);
    await start(req, rows[0]); res.status(201).json(rows[0]);
  } catch (e) { res.status(e.code === '23505' ? 409 : 500).json({ error: e.code === '23505' ? 'Não foi possível criar a conta com esses dados.' : 'Erro interno.' }); }
});
r.post('/login', limiter, async (req, res) => {
  const p = log.safeParse(req.body);
  const { rows } = p.success ? await pool.query('SELECT * FROM users WHERE email=$1', [p.data.email]) : { rows: [] };
  const ok = rows[0] && await bcrypt.compare(p.data.password, rows[0].password_hash);
  if (!ok) return res.status(401).json({ error: 'E-mail ou senha incorretos.' });
  await start(req, rows[0]); res.json({ id: rows[0].id, name: rows[0].name, glucose_unit: rows[0].glucose_unit });
});
r.post('/logout', (req, res) => req.session.destroy(() => { res.clearCookie('sid'); res.json({ ok: true }); }));
r.get('/me', async (req, res) => {
  if (!req.session.userId) return res.status(401).json({ error: 'Não autenticado.' });
  const { rows } = await pool.query('SELECT id,name,glucose_unit FROM users WHERE id=$1', [req.session.userId]);
  rows[0] ? res.json(rows[0]) : res.status(401).json({ error: 'Não autenticado.' });
});
export default r;

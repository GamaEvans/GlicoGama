import { Router } from 'express';
import { z } from 'zod';
import { pool } from '../db.js';
const r = Router();
const MOMENTS = ['jejum','antes_almoco','depois_almoco','antes_janta','depois_janta','antes_outras','depois_outras','antes_dormir','madrugada','avulsa'];
// Conversão: 1 mmol/L de glicose = 18,016 mg/dL.
const toMgdl = (v, u) => u === 'mmol/L' ? Math.round(v * 18.016 * 10) / 10 : v;
const body = z.object({
  value: z.number().positive().max(2000), unit: z.enum(['mg/dL','mmol/L']),
  measured_at: z.string().datetime({ offset: true }), moment: z.enum(MOMENTS), notes: z.string().max(1000).optional().nullable() });
// Todas as consultas filtram por user_id da sessão: nunca confiamos em IDs do cliente.
r.get('/', async (req, res) => {
  const { from, to, moment, order } = req.query; const a = [req.session.userId]; let w = 'user_id=$1';
  if (from) { a.push(from); w += ` AND measured_at>=$${a.length}`; }
  if (to) { a.push(to); w += ` AND measured_at<=$${a.length}`; }
  if (moment && MOMENTS.includes(moment)) { a.push(moment); w += ` AND moment=$${a.length}`; }
  try {
    const dir = order === 'asc' ? 'ASC' : 'DESC';
    const { rows } = await pool.query(`SELECT id,value_original,unit_original,value_mgdl,measured_at,moment,notes FROM glucose_readings WHERE ${w} ORDER BY measured_at ${dir} LIMIT 1000`, a);
    const v = rows.map(x => +x.value_mgdl);
    const stats = v.length ? { count: v.length, avg_mgdl: +(v.reduce((s,x)=>s+x,0)/v.length).toFixed(1), min_mgdl: Math.min(...v), max_mgdl: Math.max(...v) } : { count: 0 };
    res.json({ readings: rows, stats });
  } catch { res.status(400).json({ error: 'Filtros inválidos.' }); }
});
r.post('/', async (req, res) => {
  const p = body.safeParse(req.body); if (!p.success) return res.status(400).json({ error: 'Dados inválidos.' });
  const d = p.data;
  const { rows } = await pool.query('INSERT INTO glucose_readings(user_id,value_original,unit_original,value_mgdl,measured_at,moment,notes) VALUES($1,$2,$3,$4,$5,$6,$7) RETURNING id',
    [req.session.userId, d.value, d.unit, toMgdl(d.value, d.unit), d.measured_at, d.moment, d.notes ?? null]);
  res.status(201).json(rows[0]);
});
r.patch('/:id(\\d+)', async (req, res) => {
  const p = body.safeParse(req.body); if (!p.success) return res.status(400).json({ error: 'Dados inválidos.' });
  const d = p.data;
  const { rowCount } = await pool.query('UPDATE glucose_readings SET value_original=$3,unit_original=$4,value_mgdl=$5,measured_at=$6,moment=$7,notes=$8 WHERE id=$1 AND user_id=$2',
    [req.params.id, req.session.userId, d.value, d.unit, toMgdl(d.value, d.unit), d.measured_at, d.moment, d.notes ?? null]);
  rowCount ? res.json({ ok: true }) : res.status(404).json({ error: 'Registro não encontrado.' });
});
r.delete('/:id(\\d+)', async (req, res) => {
  const { rowCount } = await pool.query('DELETE FROM glucose_readings WHERE id=$1 AND user_id=$2', [req.params.id, req.session.userId]);
  rowCount ? res.json({ ok: true }) : res.status(404).json({ error: 'Registro não encontrado.' });
});
export default r;

import 'dotenv/config';
import express from 'express';
import helmet from 'helmet';
import session from 'express-session';
import connectPg from 'connect-pg-simple';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { pool } from './db.js';
import { requireAuth, csrfGuard } from './middleware/auth.js';
import authRoutes from './routes/auth.js';
import glucoseRoutes from './routes/glucose.js';
if (!process.env.SESSION_SECRET || !process.env.DATABASE_URL) { console.error('Configure DATABASE_URL e SESSION_SECRET no .env'); process.exit(1); }
const prod = process.env.NODE_ENV === 'production';
const app = express();
if (prod) app.set('trust proxy', 1);
app.use(helmet({ contentSecurityPolicy: { directives: { defaultSrc: ["'self'"], scriptSrc: ["'self'", 'https://cdn.jsdelivr.net'], styleSrc: ["'self'", 'https://fonts.googleapis.com'], fontSrc: ["'self'", 'https://fonts.gstatic.com'], imgSrc: ["'self'", 'data:'] } } }));
app.use(express.json({ limit: '50kb' }));
app.use(session({ name: 'sid', store: new (connectPg(session))({ pool, tableName: 'session' }), secret: process.env.SESSION_SECRET, resave: false, saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: 'lax', secure: prod, maxAge: 7*24*3600*1000 } }));
app.use('/api', csrfGuard);
app.use('/api/auth', authRoutes);
app.use('/api/glucose', requireAuth, glucoseRoutes);
const pub = path.join(path.dirname(fileURLToPath(import.meta.url)), '..', 'public');
const priv = ['/dashboard.html'];
app.use((req, res, next) => priv.includes(req.path) && !req.session.userId ? res.redirect('/login.html') : next());
app.use(express.static(pub, { index: 'login.html' }));
app.use((err, req, res, next) => { console.error(err.message); res.status(500).json({ error: 'Erro interno.' }); }); // sem vazar detalhes nem dados de saúde
app.listen(process.env.PORT || 3000, () => console.log('Rodando na porta', process.env.PORT || 3000));

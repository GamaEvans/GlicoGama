export const requireAuth = (req, res, next) =>
  req.session?.userId ? next() : res.status(401).json({ error: 'Faça login para continuar.' });
// Proteção CSRF: cookie SameSite + exigência de cabeçalho customizado em métodos que alteram dados.
export const csrfGuard = (req, res, next) =>
  ['GET','HEAD','OPTIONS'].includes(req.method) || req.get('X-Requested-With') === 'caderno'
    ? next() : res.status(403).json({ error: 'Requisição não permitida.' });

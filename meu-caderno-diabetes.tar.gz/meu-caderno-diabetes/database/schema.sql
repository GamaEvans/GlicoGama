CREATE TABLE IF NOT EXISTS users(
 id BIGSERIAL PRIMARY KEY, name TEXT NOT NULL, email TEXT NOT NULL UNIQUE,
 password_hash TEXT NOT NULL, glucose_unit TEXT NOT NULL DEFAULT 'mg/dL' CHECK(glucose_unit IN('mg/dL','mmol/L')),
 created_at TIMESTAMPTZ NOT NULL DEFAULT now());
-- Valor original e unidade são preservados; value_mgdl é só normalização para cálculos.
CREATE TABLE IF NOT EXISTS glucose_readings(
 id BIGSERIAL PRIMARY KEY, user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 value_original NUMERIC(6,2) NOT NULL CHECK(value_original>0), unit_original TEXT NOT NULL CHECK(unit_original IN('mg/dL','mmol/L')),
 value_mgdl NUMERIC(6,1) NOT NULL, measured_at TIMESTAMPTZ NOT NULL,
 moment TEXT NOT NULL, notes TEXT, created_at TIMESTAMPTZ NOT NULL DEFAULT now());
CREATE INDEX IF NOT EXISTS idx_glucose_user_time ON glucose_readings(user_id, measured_at DESC);
CREATE TABLE IF NOT EXISTS "session"(sid VARCHAR PRIMARY KEY, sess JSON NOT NULL, expire TIMESTAMP(6) NOT NULL);
CREATE INDEX IF NOT EXISTS idx_session_expire ON "session"(expire);
